/* @author VectroLabs */

// Export configuration variables
module.exports = {
    token: "", // Your bot token
    prefix: ":", // Your bot prefix
};