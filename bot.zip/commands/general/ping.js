/* @author VectroLabs */

module.exports = {
    name: 'ping',
    description: 'Replies with Pong!',
    /**
     * Executes the ping command.
     * @param {import('discord.js').Message} message The message object.
     */
    execute(message) {
        message.reply('🏓 Pong!');
    }
};