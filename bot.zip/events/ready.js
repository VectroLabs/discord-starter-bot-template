/* @author VectroLabs */
/**
 * Executes once when the client is ready.
 * @param {import('discord.js').Client} client The Discord client.
 */
module.exports = {
    name: 'ready',
    once: true,
    execute(client) {
        console.log(`✅ Logged in as ${client.user.tag}!`);
    }
};