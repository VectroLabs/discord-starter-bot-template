/* @author VectroLabs */
const { prefix } = require('../config/config');

/**
 * Handles incoming messages to check for prefix commands.
 * @param {import('discord.js').Message} message The message object.
 * @param {import('discord.js').Client} client The Discord client.
 */
module.exports = {
    name: 'messageCreate',
    execute(message, client) {
        // Ignore messages that don't start with the prefix or are from bots
        if (!message.content.startsWith(prefix) || message.author.bot) {
            return;
        }

        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();
        const command = client.commands.get(commandName);

        // Execute the command if it exists
        if (command) {
            try {
                command.execute(message, args, client);
            } catch (error) {
                console.error(`Error executing prefix command "${commandName}":`, error);
                message.reply('There was an error trying to execute that command!');
            }
        }
    }
};