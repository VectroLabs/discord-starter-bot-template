/* @author VectroLabs */

const { Client, GatewayIntentBits, Partials, Collection } = require('discord.js');
const { token } = require('./config/config');
const fs = require('fs');

// Create Discord client with optimized intents and partials
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ],
    partials: [Partials.Channel]
});

// Initialize command collections
client.commands = new Collection();

// Load handlers
['commandHandler', 'eventHandler'].forEach(handler => {
    require(`./handlers/${handler}`)(client);
});

// Log in the bot
client.login(token);