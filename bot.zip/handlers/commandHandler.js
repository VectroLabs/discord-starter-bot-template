/* @author VectroLabs */
const fs = require('fs');
const path = require('path');
const { prefix } = require('../config/config');

/**
 * Loads all prefix commands from the 'prefix' directory.
 * @param {import('discord.js').Client} client The Discord client instance.
 */
module.exports = (client) => {
    const prefixCommandsPath = path.join(__dirname, '../commands');
    const commandFolders = fs.readdirSync(prefixCommandsPath);

    for (const folder of commandFolders) {
        const folderPath = path.join(prefixCommandsPath, folder);
        const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith('.js'));
        for (const file of commandFiles) {
            const filePath = path.join(folderPath, file);
            const command = require(filePath);
            // Ensure the command has a 'name' property before setting it.
            if (command.name) {
                client.commands.set(command.name, command);
            } else {
                console.warn(`[COMMANDS] Skipping file: ${file} as it doesn't have a 'name' property.`);
            }
        }
    }

    console.log(`[COMMANDS] Loaded ${client.commands.size} prefix commands with prefix "${prefix}".`);
};