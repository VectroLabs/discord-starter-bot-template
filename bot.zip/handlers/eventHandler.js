/* @author VectroLabs */
const fs = require('fs');
const path = require('path');

/**
 * Loads all event files from the 'events' directory.
 * @param {import('discord.js').Client} client The Discord client instance.
 */
module.exports = (client) => {
    const eventsPath = path.join(__dirname, '../events');
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

    for (const file of eventFiles) {
        const filePath = path.join(eventsPath, file);
        const event = require(filePath);
        if (event.once) {
            client.once(event.name, (...args) => event.execute(...args, client));
        } else {
            client.on(event.name, (...args) => event.execute(...args, client));
        }
        console.log(`[EVENTS] Loaded event: ${event.name}`);
    }

    console.log(`[EVENTS] Successfully loaded ${eventFiles.length} events.`);
};